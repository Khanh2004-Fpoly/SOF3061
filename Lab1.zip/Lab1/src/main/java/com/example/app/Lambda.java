package com.example.app;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.example.bean.Student;

public class Lambda {
	
	static List<Student> list = Arrays.asList(
			new Student("Nguyễn Hoàng Khánh", true, 7.5),
			new Student("Châu Ngọc Trung", false, 7.0),
			new Student("Nguyễn Trần Hoàng Phát", false, 6.5),
			new Student("Bùi Trần Thanh Huy", false, 9.0),
			new Student("Nguyễn Duy Liêm", false, 8.0)
			);
	
	public static void main(String[] args) {
		demo1();
		demo2();
		demo3();
		demo4();
	}
	private static void demo1() {
		List<Integer> list = Arrays.asList(1,2,3,4,5,6);
		list.forEach(n -> System.out.println(n));
	}
	private static void demo2() {
		list.forEach(sv -> {
			System.out.println(">> Name: " + sv.getName());
			System.out.println(">> Marks: " + sv.getMarks());
			System.out.println();
		});
	}
	private static void demo3() {
		Collections.sort(list, (sv1,sv2) -> sv1.getMarks().compareTo(sv2.getMarks()));
		list.forEach(sv -> {
			System.out.println(">> Name: " + sv.getName());
			System.out.println(">> Marks: " + sv.getMarks());
			System.out.println();
		});
	}
	private static void demo4() {
		Demo4Inter o = x -> System.out.println(x);
		o.m1(2025);
	}
	
	@FunctionalInterface
	interface Demo4Inter{
		void m1(int x);
		default void m2() {}
		public static void m3() {}
	}
}
